package desafio;

public class Email {
	private String enderecoEmail;	
	
	public Email(String enderecoEmail) {
		this.enderecoEmail = enderecoEmail;
	}

	
	public String getEnderecoEmail() {
		return this.enderecoEmail;
	}

	public void setEnderecoEmail(String enderecoEmail) {
		this.enderecoEmail = enderecoEmail;
	}

}
